#include"function.h"
#include "interface.h"

void main()
{
	DATABASE_RECORD databaseData[10000];
	memset(foundId, -1, sizeof(foundId));
	ReadFile(databaseData);
	MainMenu(databaseData);
}